<?php
class Administrator extends User {

	function __construct($userRow = NULL) {
		parent::__construct($userRow);
	}

}
?>