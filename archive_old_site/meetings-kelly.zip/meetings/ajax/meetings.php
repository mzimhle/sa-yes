<?php
session_start();
require_once ('models.php');

$dbm = DBManager::getInstance();

// get current user
$currentUser = $_SESSION['user'];
if (!isset($currentUser)) { echo 'not authorized';
}
$currentUser = $dbm -> getUser($currentUser);

if (isset($currentUser)) {

	$meetingData = $dbm -> getMeetingsAjax($currentUser);

	$meetings = $meetingData['meetings'];
	$totalRecords = $meetingData['totalCount'];
	$filteredRecords = $meetingData['filteredCount'];

	// check for errors
	if (PEAR::isError($meetings)) {
		echo '{ "error": "' . $meetings -> getMessage() . '" }';
	} else if (PEAR::isError($totalRecords)) {
		echo '{ "error": "' . $totalRecords -> getMessage() . '" }';
	} else if (PEAR::isError($filteredRecords)) {
		echo '{ "error": "' . $filteredRecords -> getMessage() . '" }';
	} else {

		// build data expected by DataTable
		$output = array(
			"sEcho" => intval($_GET['sEcho']),
			"iTotalRecords" => $meetingData['totalCount'],
			"iTotalDisplayRecords" => $meetingData['filteredCount'],
			"aaData" => array()
		);

		// process each meeting and add to output
		foreach ($meetingData['meetings'] as $key => $meetingRow) {
			$meeting = meetingToArray($dbm, $meetingRow, $currentUser);
			$output['aaData'][] = $meeting;
		}

		echo json_encode($output);
	}
}

/**
 * Converts the given row of meeting data into an array of information suitable
 * for ingestion by the DataTable
 *
 * @param dbm database manager instance
 * @param row row of meeting information from the database
 * @param user current user used to determine columns to return
 * @return array of formatted data
 */
function meetingToArray($dbm, $row, $user) {

	$id = $row['id'];
	$date = $row['date'];
	$status = $row['status'];
	$mentorId = $row['mentor'];
	$menteeId = $row['mentee'];
	$type = $row['type'];
	$withStaff = $row['staff'];
	$startTime = $row['start_time'];
	$length = $row['length'];
	$reason = $row['reason'];
	$notes = $row['notes'];
	$adminNotes = $row['notes_admin'];
	$active = $row['active'];

	$meeting = array();
	$meeting[] = '<img src="css/images/details_open.png">';
	
	// include sortable date comment
	if (date) {
		$pieces = explode('-',$date);
		$sortDate = '<!--'.$pieces[0].$pieces[1].$pieces[2].'-->';
		$meeting[] = $sortDate . $date;		
	} else {
		$meeting[] = '';
	}	
	
	if ($user instanceof Administrator) {
		
		// get display names
		$mentor = $dbm -> getDisplayName($mentorId);
		$mentee = $dbm -> getDisplayName($menteeId);

		$meeting[] = isset($mentor) ? $mentor : '';
		$meeting[] = isset($mentee) ? $mentee : '';
	}
	$meeting[] = $status ? 'Yes' : 'No';
	$meeting[] = isset($type) ? $type : '';
	$meeting[] = $withStaff ? 'Yes' : 'No';
	$meeting[] = isset($startTime) ? $startTime : '';
	$meeting[] = isset($length) ? $length : '';
	$meeting[] = isset($reason) ? $reason : '';
	$meeting[] = isset($notes) ? $notes : '';
	if ($user instanceof Administrator) {
		$meeting[] = isset($adminNotes) ? $adminNotes : '';
		$meeting[] = isset($active) ? $active : '';
	}

	// add row id
	$meeting['DT_RowId'] = 'row' . $id;

	return $meeting;
}
?>