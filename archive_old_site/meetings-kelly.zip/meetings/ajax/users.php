<?php
session_start();
require_once ('models.php');

$dbm = DBManager::getInstance();

// get current user
$currentUser = $_SESSION['user'];
if (!isset($currentUser)) { echo 'not authorized';
}
$currentUser = $dbm -> getUser($currentUser);

if (isset($currentUser) && $currentUser instanceof Administrator) {

	$userType = $_GET['type'];

	$userData = $dbm -> getUsersAjax($userType);

	$users = $userData['users'];
	$totalRecords = $userData['totalCount'];
	$filteredRecords = $userData['filteredCount'];

	// check for errors
	if (PEAR::isError($users)) {
		echo '{ "error": "' . $users -> getMessage() . '" }';
	} else if (PEAR::isError($totalRecords)) {
		echo '{ "error": "' . $totalRecords -> getMessage() . '" }';
	} else if (PEAR::isError($filteredRecords)) {
		echo '{ "error": "' . $filteredRecords -> getMessage() . '" }';
	} else {

		// build data expected by DataTable
		$output = array(
			"sEcho" => intval($_GET['sEcho']),
			"iTotalRecords" => $totalRecords,
			"iTotalDisplayRecords" => $filteredRecords,
			"aaData" => array()
		);

		// process each user and add to output
		foreach ($users as $key => $userRow) {
			$user = userToArray($dbm, $userRow, $userType);
			$output['aaData'][] = $user;
		}

		echo json_encode($output);
	}
}

/**
 * Converts the given row of user data into an array of information suitable
 * for ingestion by the DataTable
 *
 * @param dbm database manager instance
 * @param row row of user information from the database
 * @param userType type of user the user information represents
 * @return array of formatted data
 */
function userToArray($dbm, $row, $userType) {

	$id = $row['id'];	
	$fname = $row['first_name'];
	$lname = $row['last_name'];
	$email = $row['email'];
	$active = $row['active'];
	$phone = $row['phone'];
	$cphone = $row['cphone'];
	$notes = $row['notes'];
	if ($userType == 'Mentor' || $userType == 'Mentee') {
		$joinDate = $row['join_date'];
	}
	if ($userType == 'Mentee') {
		$race = $row['race'];
		$home = $row['home'];
		$homeDetails = $row['home_details'];
	}

	$user = array();
	$user[] = '<img src="css/images/details_open.png">';
	$user[] = isset($fname) ? $fname : '';
	$user[] = isset($lname) ? $lname : '';
	$user[] = isset($email) ? $email : '';
	$user[] = isset($phone) ? $phone : '';
	$user[] = isset($cphone) ? $cphone : '';
	if ($userType == 'Mentor' || $userType == 'Mentee') {
		$user[] = isset($joinDate) ? $joinDate : '';
	}
	if ($userType == 'Mentee') {
		$user[] = isset($race) ? $race : '';
		$user[] = isset($home) ? $home : '';
		$user[] = isset($homeDetails) ? '<pre>'.$homeDetails.'</pre>' : '';
	}
	$user[] = isset($notes) ? '<pre>'.$notes.'</pre>' : '';

	// add row id
	if ($userType == 'Administrator') {
		$user['DT_RowId'] = 'usersAdmin_row' . $id;
	} else if ($userType == 'Mentor') {
		$user['DT_RowId'] = 'usersMentor_row' . $id;
	} else if ($userType == 'Mentee') {
		$user['DT_RowId'] = 'usersMentee_row' . $id;
	}
	
	// add deactivated class
	if (($userType == 'Mentor' || $userType == 'Mentee' ) && !$active) {
		$user['DT_RowClass'] = 'deactivated';
	}

	return $user;
}
?>