<table id="meetings" class="display adminMeetings" style="table-layout: fixed">
	<thead>
	<tr>
		<th style="width: 9em">Date</th>
		<th style="width: 11em">Mentor Name</th>
		<th style="width: 11em">Mentee Name</th>
		<th style="width: 8em">Meeting Status</th>
		<th style="width: 8em">Type</th>
		<th style="width: 7em">With Staff</th>
		<th style="width: 8em">Start Time</th>
		<th style="width: 8em">Length (hours)</th>
		<th>Reason</th>
		<th>Notes</th>
		<th>Admin Notes</th>
		<th>Active</th>
	</tr>
	</thead>
	<tbody>
		<?php // populated via AJAX ?>
	</tbody>
	<tfoot>
		<tr>
			<th><input type="text" name="search_date" value="Search dates" class="search_init" col="1" /></th>
			<th><input type="text" name="search_mentor" value="Search mentors" class="search_init" col="2" /></th>
			<th><input type="text" name="search_mentee" value="Search mentees" class="search_init" col="3 "/></th>
			<th><select col="4"><option></option><option>Yes</option><option>No</option></select></th>
			<th><input type="text" name="search_type" value="Search types" class="search_init" col="5" /></th>
			<th><input type="text" name="search_withstaff" value="Search with staff" class="search_init" col="6" /></th>
			<th><input type="text" name="search_start" value="Search start time" class="search_init" col="7" /></th>
			<th><input type="text" name="search_length" value="Search length" class="search_init" col="8" /></th>
			<th><input type="text" name="search_reason" value="Search reason" class="search_init" col="9" /></th>
			<th><input type="text" name="search_notes" value="Search notes" class="search_init" col="10" /></th>
			<th><input type="text" name="search_notes_admin" value="Search admin notes" class="search_init" col="11" /></th>
			<th><input type="text" name="search_active" value="Search active status" class="search_init" col="12" /></th>
		</tr>
	</tfoot>
</table>

<div id="addAdminNotes" title="Edit Admin Notes" style="display:none">
		<form id="addAdminNotesForm" class="form" name="addAdminNotes">
			<input id="addNotesId" type="hidden" name="meetingId" value="" />
			<div>
				<p>
					<label for="fname">Admin Notes</label>
					<textarea id="addAdminNotesField" class="input" name="adminNotes" />
				</p>
			</div>
		</form>
	</div>
	