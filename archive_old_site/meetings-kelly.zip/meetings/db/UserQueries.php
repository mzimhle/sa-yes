<?php
class UserQueries {

	/** DBManager instance for utility functions */
	private $dbUtils;

	/** MDB2 instance for performing queries */
	private $mdb2;

	// limit things to only after this date
	private $date_limit = '2010-12-01';

	function __construct($dbm, $mdb2) {
		$this -> dbUtils = $dbm;
		$this -> mdb2 = $mdb2;
	}

	/**
	 * Return the id of the last inserted user row
	 *
	 * @return id of the last inserted row
	 */
	public function getLastUserId() {
		$sth = $this -> mdb2 -> prepare("SELECT users.id FROM users WHERE users.id = LAST_INSERT_ID()");
		$result = $sth -> execute();
		$row = $result -> fetchRow(MDB2_FETCHMODE_ASSOC);
		return $row['id'];
	}

	/**
	 * Returns a User object for the user with the given id
	 *
	 * @param $id id of the user
	 * @return a populated User object
	 */
	public function getUser($id) {

		$types = array('integer');
		$sth = $this -> mdb2 -> prepare("SELECT * FROM users WHERE users.id = :id", $types);
		$params = array('id' => $id);
		$result = $sth -> execute($params);

		if (PEAR::isError($result)) {
			return $result;
		}

		$row = $result -> fetchRow(MDB2_FETCHMODE_ASSOC);
		$result -> free();

		// check user type
		$groupId = $row['user_group'];
		$group = $this -> getGroupAlias($groupId);

		// create user object
		switch($group) {
			case "Administrator" :
				$user = new Administrator($row);
				break;
			case 'Mentor' :
				$user = new Mentor($row);
				break;
			case 'Mentee' :
				$user = new Mentee($row);
				break;
			default :
				$user = new User($row);
		}

		return $user;
	}

	/**
	 * Returns a User object for the user with the given email
	 *
	 * @param $email email of the user
	 * @return a populated User object
	 */
	public function getUserByEmail($email) {

		$types = array('text');
		$sth = $this -> mdb2 -> prepare("SELECT * FROM users WHERE users.email = :email", $types);
		$params = array('email' => $email);
		$result = $sth -> execute($params);

		if (PEAR::isError($result)) {
			return $result;
		}

		$row = $result -> fetchRow(MDB2_FETCHMODE_ASSOC);
		$result -> free();

		// check user type
		$groupId = $row['user_group'];
		$group = $this -> getGroupAlias($groupId);

		// create user object
		switch($group) {
			case "Administrator" :
				$user = new Administrator($row);
				break;
			case 'Mentor' :
				$user = new Mentor($row);
				break;
			case 'Mentee' :
				$user = new Mentee($row);
				break;
			default :
				$user = new User($row);
		}

		return $user;
	}

	/**
	 * Returns the alias of the group with the given id.
	 *
	 * @param groupId id of the group
	 * @return the alias of the group
	 */
	function getGroupAlias($groupId) {

		$query = "SELECT alias FROM groups WHERE groups.id = :id";
		$types = array('integer');
		$params = array('id' => $groupId);
		$sth = $this -> mdb2 -> prepare($query, $types);
		$result = $sth -> execute($params);

		if (PEAR::isError($result)) {
			return $result;
		}

		$row = $result -> fetchRow(MDB2_FETCHMODE_ASSOC);
		$result -> free();

		if (isset($row)) {
			return $row['alias'];
		}

		return null;
	}

	/**
	 * Returns whether or not the given user has administrator privileges
	 *
	 * @param userId id of the user to check
	 * @return whether or not the user has administrator privileges
	 */
	function isAdmin($userId) {
		$adminGroupId = $this -> getGroupId('Administrator');

		$query = "SELECT user_group FROM users where id = $userId";
		$row = $this -> dbUtils -> doSingleSelect($query);

		if (PEAR::isError($row)) {
			return false;
		}

		if (isset($row)) {
			return $adminGroupId == $row['user_group'];
		}

		return false;
	}

	/**
	 * Returns whether or not the given user is a mentor
	 *
	 * @param userId id of the user to check
	 * @return whether or not the user is a mentor
	 */
	function isMentor($userId) {
		$mentorGroupId = $this -> getGroupId('Mentor');

		$query = "SELECT user_group FROM users where id = $userId";
		$row = $this -> dbUtils -> doSingleSelect($query);

		if (PEAR::isError($row)) {
			return false;
		}

		if (isset($row)) {
			return $mentorGroupId == $row['user_group'];
		}

		return false;
	}

	/**
	 * Returns the id of the group with the given name.
	 *
	 * @param groupAlias alias of the group
	 * @return the id of the group
	 */
	function getGroupId($groupAlias) {

		$query = "SELECT id FROM groups WHERE groups.alias = :alias";
		$types = array('text');
		$params = array('alias' => $groupAlias);
		$sth = $this -> mdb2 -> prepare($query, $types);
		$result = $sth -> execute($params);

		if (PEAR::isError($result)) {
			return $result;
		}

		$row = $result -> fetchRow(MDB2_FETCHMODE_ASSOC);
		$result -> free();

		if (isset($row)) {
			return $row['id'];
		}

		return null;
	}

	/**
	 * Returns the type of the user (Mentor, Mentee, Admin) specified by the
	 * given user id
	 *
	 * @param userId id of the user
	 * @return the user type
	 */
	function getUserType($userId) {

		$types = array('integer');
		$sth = $this -> mdb2 -> prepare("SELECT users.user_group FROM users WHERE users.id = :id", $types);
		$params = array('id' => $userId);
		$result = $sth -> execute($params);

		if (PEAR::isError($result)) {
			return $result;
		}

		$row = $result -> fetchRow(MDB2_FETCHMODE_ASSOC);
		$result -> free();

		// get user type
		$groupId = $row['user_group'];
		$group = $this -> getGroupAlias($groupId);

		return $group;
	}

	/**
	 * Returns a list of valid user types
	 *
	 * @return list of user types
	 */
	function getUserTypes() {

		$types = array();

		$query = "SELECT alias FROM groups";
		$rows = $this -> dbUtils -> doMultiSelect($query);

		foreach ($rows as $key => $row) {
			$types[] = $row['alias'];
		}

		return $types;
	}

	/**
	 * Deletes a user from the database
	 *
	 * @param String $userId id of the user to delete
	 */
	public function deleteUser($userId) {

		$query = "UPDATE users SET users.deleted = true WHERE users.id = :id";
		$query = "DELETE FROM users WHERE users.id = :id";
		$types = array('integer');
		$params = array('id' => $userId);
		$sth = $this -> mdb2 -> prepare($query, $types);
		$result = $sth -> execute($params);

		if (PEAR::isError($result)) {
			return $result;
		}

		$result -> free();

		// TODO delete matches and meetings

		return $result;
	}

	/**
	 * Inserts the given user into the database
	 *
	 * @param user user to save
	 * @return number of rows affected, or error
	 */
	public function newUser($user) {

		// email is required for mentor and admins, but not mentees

		//$email = $user -> getEmail();
		//if (isset($user) && isset($email)) {
		if (isset($user)) {

			// email is required
			//$attrs = 'email';
			//$values = "'$email'";

			// first name is required
			$firstName = $user -> getFirstName();
			$attrs = 'first_name';
			$values = "'$firstName'";

			// if (isset($firstName)) {
			// $attrs .= ',first_name';
			// $values .= ",'$firstName'";
			// }

			$lastName = $user -> getLastName();
			if (isset($lastName)) {
				$attrs .= ',last_name';
				$values .= ",'$lastName'";
			}

			$email = $user -> getEmail();
			if (isset($email)) {
				$attrs .= ',email';
				$values .= ",'$email'";
			}

			$password = $user -> getPassword();
			if (isset($password)) {
				$attrs .= ',password';
				$values .= ",PASSWORD('$password')";
			}

			$phone = $user -> getPhone();
			if (isset($phone)) {
				$attrs .= ',phone';
				$values .= ",'$phone'";
			}

			$cell = $user -> getCell();
			if (isset($cell)) {
				$attrs .= ',cphone';
				$values .= ",'$cell'";
			}

			$notes = $user -> getNotes();
			if (isset($notes)) {
				$attrs .= ',notes';
				$values .= ",'$notes'";
			}

			$dbm = DBManager::getInstance();

			$groupId = "";
			if ($user instanceof Administrator) {
				$groupId = $this -> getGroupId("Administrator");
			} else if ($user instanceof Mentor) {
				$groupId = $this -> getGroupId("Mentor");

				$menteeId = $user -> getMenteeId();
				if (isset($menteeId)) {
					$attrs .= ',mentee';
					$values .= ",'$menteeId'";
				}

				$joinDate = $user -> getJoinDate();
				if (isset($joinDate)) {
					$attrs .= ',join_date';
					$values .= ",'$joinDate'";
				}
			} else if ($user instanceof Mentee) {
				$groupId = $this -> getGroupId("Mentee");

				$home = $user -> getHome();
				if (isset($home)) {
					$attrs .= ',home';
					$values .= ",'$home'";
				}

				$homeDetails = $user -> getHomeDetails();
				if (isset($homeDetails)) {
					$attrs .= ',home_details';
					$values .= ",'$homeDetails'";
				}

				$joinDate = $user -> getJoinDate();
				if (isset($joinDate)) {
					$attrs .= ',join_date';
					$values .= ",'$joinDate'";
				}
			}
			$attrs .= ',user_group';
			$values .= ",'$groupId'";

			$query = "INSERT INTO users ($attrs) VALUES ($values)";
			$affected = $this -> dbUtils -> doSingleSelect($query);

			return $affected;
		}
	}

	/**
	 * Activates or deactivates the user with the given id based on the given active
	 * state
	 *
	 * @param userId id of the user to activate/deactive
	 * @param active whether the user should be set to active or deactive
	 * @return number of affected rows, or error
	 */
	public function activateUser($userId, $active) {

		// ensure 'active' is a boolean
		if ($active === 'false')
			$active = false;
		else {
			$active = true;
		}

		$query = "UPDATE users SET users.active = :active WHERE users.id = :userId";
		$types = array(
			'boolean',
			'integer'
		);
		$params = array(
			'active' => $active,
			'userId' => $userId
		);

		$sth = $this -> mdb2 -> prepare($query, $types, MDB2_PREPARE_MANIP);
		$result = $sth -> execute($params);

		if (PEAR::isError($result)) {
			return $result;
		}

		return $result;
	}

	/**
	 * Returns all users of the selected type. If no type is specified, returns all
	 * users.
	 *
	 * @param type type of users to return
	 * @return all users of the specified type as rows
	 */
	public function getUsers($type = NULL) {

		if (isset($type)) {
			$groupId = $this -> getGroupId($type);
			$query = "SELECT * FROM users WHERE user_group = :id AND users.deleted = false ORDER BY last_name";
			$types = array('integer');
			$params = array('id' => $groupId);
		} else {
			$query = "SELECT * FROM users ORDER BY last_name";
			$types = array();
			$params = array();
		}

		$sth = $this -> mdb2 -> prepare($query, $types);
		$result = $sth -> execute($params);

		if (PEAR::isError($result)) {
			return $result;
		}

		$rows = $result -> fetchAll(MDB2_FETCHMODE_ASSOC);
		$result -> free();

		return $rows;
	}

	/**
	 * Updates a user's information. Given user object contains the user id and all
	 * values that should be set in the database.
	 *
	 * @param updatedUser user object containing updated information
	 */
	public function updateUser($updatedUser) {

		$fields = '';
		$types = array();
		$params = array();

		// first name
		$fname = $updatedUser -> getFirstName();
		if ($fname != null) {
			$fields .= "users.first_name=?,";
			array_push($types, 'text');
			array_push($params, $fname);
		}

		// last name
		$lname = $updatedUser -> getLastName();
		if ($fname != null) {
			$fields .= "users.last_name=?,";
			array_push($types, 'text');
			array_push($params, $lname);
		}

		// email
		$email = $updatedUser -> getEmail();
		if ($email != null) {
			$fields .= "users.email=?,";
			array_push($types, 'text');
			array_push($params, $email);
		}

		// cell phone
		$cell = $updatedUser -> getCell();
		$fields .= "users.cphone=?,";
		array_push($types, 'text');
		array_push($params, $cell);

		// phone
		$phone = $updatedUser -> getPhone();
		$fields .= "users.phone=?,";
		array_push($types, 'text');
		array_push($params, $phone);

		// notes
		$notes = $updatedUser -> getNotes();
		$fields .= "users.notes=?,";
		array_push($types, 'text');
		array_push($params, $notes);

		// race
		if ($updatedUser instanceof Mentee) {
			$race = $updatedUser -> getRace();
			$fields .= "users.race=?,";
			array_push($types, 'text');
			array_push($params, $race);
		}

		// home
		if ($updatedUser instanceof Mentee) {
			$home = $updatedUser -> getHome();
			$fields .= "users.home=?,";
			array_push($types, 'text');
			array_push($params, $home);
		}

		// home details
		if ($updatedUser instanceof Mentee) {
			$homeDetails = $updatedUser -> getHomeDetails();
			$fields .= "users.home_details=?,";
			array_push($types, 'text');
			array_push($params, $homeDetails);
		}

		// join date
		if ($updatedUser instanceof Mentee || $updatedUser instanceof Mentor) {
			$joinDate = $updatedUser -> getJoinDate();
			$fields .= "users.join_date=?,";
			array_push($types, 'text');
			array_push($params, $joinDate);
		}

		// notes
		$notes = $updatedUser -> getNotes();
		$fields .= "users.notes=?,";
		array_push($types, 'text');
		array_push($params, $notes);

		// password
		$pw = $updatedUser -> getPassword();
		if ($pw != null && isset($pw)) {
			$fields .= "users.password=PASSWORD(?),";
			array_push($types, 'text');
			array_push($params, $pw);
		}

		// remove trailing comma
		$fields = substr($fields, 0, $fields . length - 1);

		// add id values to types and params
		array_push($types, 'integer');
		array_push($params, $updatedUser -> getId());

		// build and execute query
		$query = "UPDATE users SET " . $fields . " WHERE users.id=?";
		$s = $this -> mdb2 -> prepare($query, $types, MDB2_PREPARE_MANIP);
		$result = $s -> execute($params);

		return $result;
	}

	/**
	 * Returns the display name for the user
	 *
	 * @param userId the id of the user whose name should be returned
	 * @return the display name of the user
	 */
	function getDisplayName($userId) {

		$query = "SELECT * FROM users WHERE users.id = :id";
		$types = array('integer');
		$params = array('id' => $userId);
		$sth = $this -> mdb2 -> prepare($query, $types);
		$result = $sth -> execute($params);

		if (PEAR::isError($result)) {
			return $result;
		}

		$row = $result -> fetchRow(MDB2_FETCHMODE_ASSOC);
		$result -> free();

		return $row['first_name'] . ' ' . $row['last_name'];
	}

	/**
	 * Returns the id of the current mentee for the given mentor
	 *
	 * @param mentorId id of the mentor whose mentee is returned
	 * @return id of the mentee
	 */
	public function getCurrentMentee($mentorId) {
		$query = "SELECT matches.mentee FROM matches WHERE matches.mentor=? ORDER BY match_date DESC";
		$types = array('integer');
		$params = array($mentorId);

		$sth = $this -> mdb2 -> prepare($query, $types);
		$result = $sth -> execute($params);

		if (PEAR::isError($result)) {
			return $result;
		}

		$row = $result -> fetchRow(MDB2_FETCHMODE_ASSOC);
		$result -> free();

		return $row['mentee'];
	}

	/**
	 * Returns an object containing the user set described by the current request
	 * params. Object contains keys: users, filteredCount, totalCount.
	 *
	 * @param type type of users to return
	 * @return meeting result set
	 */
	public function getUsersAjax($type = NULL) {

		$users = $this -> doUsersAjaxQuery($type);
		$filteredTotal = $this -> getUsersAjaxFilteredTotal();
		$total = $this -> getTotalCount('users', 'id', $type);

		return array(
			'users' => $users,
			'filteredCount' => $filteredTotal,
			'totalCount' => $total
		);
	}

	/**
	 * Returns an array of column names specifying which user table column values
	 * to return.
	 *
	 * @param type user type
	 * @return array of user table column names
	 */
	private function getUserColumns($type = NULL) {
		if ($type == 'Mentor') {
			return array(
				'id',
				'first_name',
				'last_name',
				'email',
				'phone',
				'cphone',
				'join_date',
				'notes',
				'active'
			);
		} else if ($type == "Mentee") {
			return array(
				'id',
				'first_name',
				'last_name',
				'email',
				'phone',
				'cphone',
				'race',
				'home',
				'home_details',
				'join_date',
				'notes',
				'active'
			);
		} else {
			return array(
				'id',
				'first_name',
				'last_name',
				'email',
				'active',
				'phone',
				'cphone',
				'notes'
			);			
		}
	}

	/**
	 * Get the filtered count from the users ajax query. Must be called
	 * immediately after doUsersAjaxQuery().
	 *
	 * @return filtered result count
	 */
	private function getUsersAjaxFilteredTotal() {
		/* Data set length after filtering */
		$sQuery = "SELECT FOUND_ROWS()";
		$sth = $this -> mdb2 -> prepare($sQuery);
		$result = $sth -> execute();

		if (PEAR::isError($result)) {
			return $result;
		}

		$rows = $result -> fetchAll(MDB2_FETCHMODE_ASSOC);
		$result -> free();
		return $rows[0]['found_rows()'];
	}

	/**
	 * Some columns have a different display value than db value. This function
	 * returns the appropriate value to use for database queries to filter the
	 * column.
	 *
	 * @param colName column name in database
	 * @param i column index. Unadjusted column index.
	 * @param filterValue filter value from client
	 */
	private function getFilterValue($colName, $i, $filterValue) {

		// Meeting Status
		if ($colName === 'status') {
			if ($filterValue == 'Yes') {
				return 1;
			} else if ($filterValue == 'No') {
				return 0;
			}
		}

		return mysql_real_escape_string($_GET['sSearch_' . $i]);
	}

	/**
	 * Returns the total rows in the given table
	 *
	 * @param table database table to return row count for
	 * @param column id of the column to use for counting
	 * @param type user type to return count for
	 *
	 * @return total row count
	 */
	private function getTotalCount($table, $column, $type) {
		$sQuery = "SELECT COUNT(" . $column . ") FROM $table";

		// limit to user type
		$groupId = $this -> getGroupId($type);
		$sQuery .= " WHERE user_group = " . $groupId . " AND users.deleted = false";

		$sth = $this -> mdb2 -> prepare($sQuery);
		$result = $sth -> execute();

		if (PEAR::isError($result)) {
			return $result;
		}

		$total = $result -> fetchAll(MDB2_FETCHMODE_ASSOC);
		$result -> free();

		$total = $total[0]['count(id)'];

		return $total;
	}

	/**
	 * Performs a query for users based on an ajax request from a DataTable
	 *
	 * @param type type of users to return
	 * @return array of rows
	 */
	private function doUsersAjaxQuery($type = null) {

		// define table columns
		$aColumns = $this -> getUserColumns($type);
		$sIndexColumn = "id";

		// paging
		$sLimit = $this -> dbUtils -> dt_getLimit();

		// ordering
		$sOrder = $this -> dbUtils -> dt_getOrder($aColumns);

		// filtering across all table data
		$sWhere = $this -> dbUtils -> dt_getFiltering($aColumns);

		/* Individual column filtering */
		/* Adjust i to account for details column on client-side */
		for ($i = 0; $i < count($aColumns) + 1; $i++) {
			if ($_GET['bSearchable_' . $i] == "true" && $_GET['sSearch_' . $i] != '') {
				if ($sWhere == "") {
					$sWhere = "WHERE ";
				} else {
					$sWhere .= " AND ";
				}

				/*
				 * Some columns have display values that are different from the db values. Get
				 * the appropriate value to query with.
				 */
				$filterValue = $this -> getFilterValue($aColumns[$i - 1], $i, $_GET['sSearch_' . $i]);

				// mysql_real_escape_string($_GET['sSearch_' . $i])

				$sWhere .= $aColumns[$i - 1] . " LIKE '%" . $filterValue . "%' ";
			}
		}

		// user filtering
		if (isset($type)) {
			if ($sWhere == "") {
				$sWhere = "WHERE ";
			} else {
				$sWhere .= " AND ";
			}

			$groupId = $this -> getGroupId($type);
			$sWhere .= "user_group = " . $groupId . " AND users.deleted = false";
		}

		/*
		 * SQL queries
		 * Get data to display
		 */
		$sTable = 'users';
		$sQuery = "
		SELECT SQL_CALC_FOUND_ROWS " . str_replace(" , ", " ", implode(", ", $aColumns)) . "
		FROM $sTable $sWhere $sOrder $sLimit";

		$sth = $this -> mdb2 -> prepare($sQuery);
		$result = $sth -> execute();

		if (PEAR::isError($result)) {
			return $result;
		}

		$rows = $result -> fetchAll(MDB2_FETCHMODE_ASSOC);
		$result -> free();

		return $rows;
	}

}
?>