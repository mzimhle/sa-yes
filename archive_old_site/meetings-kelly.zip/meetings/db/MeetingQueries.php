<?php
class MeetingQueries {

	/** DBManager instance for utility functions */
	private $dbUtils;

	/** MDB2 instance for performing queries */
	private $mdb2;

	// limit things to only after this date
	private $date_limit = '2010-12-01';

	function __construct($dbm, $mdb2) {
		$this -> dbUtils = $dbm;
		$this -> mdb2 = $mdb2;
	}

	/**
	 * Return the id of the last inserted meeting row
	 *
	 * @return id of the last inserted row
	 */
	public function getLastMeetingId() {
		$sth = $this -> mdb2 -> prepare("SELECT meetings.id FROM meetings WHERE meetings.id = LAST_INSERT_ID()");
		$result = $sth -> execute();
		$row = $result -> fetchRow(MDB2_FETCHMODE_ASSOC);
		return $row['id'];
	}

	/**
	 * Returns the id of the owner of the meeting with the given id.
	 *
	 * @param id id of the meeting
	 */
	public function getMeetingOwner($id) {
		$types = array('integer');
		$sth = $this -> mdb2 -> prepare("SELECT meetings.mentor FROM meetings WHERE meetings.id = :id", $types);
		$params = array('id' => $id);
		$result = $sth -> execute($params);

		if (PEAR::isError($result)) {
			return $result;
		}

		$row = $result -> fetchRow(MDB2_FETCHMODE_ASSOC);
		$mentorId = $row['mentor'];
		$result -> free();

		return $mentorId;
	}

	/**
	 * Inserts a new meeting into the database
	 *
	 * @param String $values
	 * @param String $types
	 * @param String $owner
	 * @return number of affected rows or error
	 */
	public function newMeeting($params, $types, $owner) {

		// get mentor's current mentee (meetings can only be added for active matches)
		$mentee = $this -> dbUtils -> getCurrentMentee($owner);
		$params['mentee'] = $mentee;
		array_push($types, 'integer');

		// add meeting owner
		$params['mentor'] = $owner;
		array_push($types, 'text');

		// set deleted to false
		$params['deleted'] = false;
		array_push($types, 'boolean');

		$names = '';
		$values = '';
		foreach ($params as $key => $val) {
			if ($names != '') {
				$names .= ',' . $key;
				$values .= ',:' . $key;
			} else {
				$names .= $key;
				$values .= ':' . $key;
			}
		}

		$query = "INSERT INTO meetings ($names) VALUES ($values)";

		$sth = $this -> mdb2 -> prepare($query, $types);
		$result = $sth -> execute($params);

		if (PEAR::isError($result)) {
			return $result;
		}

		$row = $result -> fetchRow(MDB2_FETCHMODE_ASSOC);
		$result -> free();

		return $row;
	}

	/**
	 * Deletes a meeting from the database
	 *
	 * @param String $meetingId id of the meeting to delete
	 */
	public function deleteMeeting($meetingId) {

		$query = "UPDATE meetings SET meetings.deleted = ? WHERE meetings.id = ?";
		$types = array(
			'integer',
			'integer'
		);
		$params = array(
			1,
			$meetingId
		);
		$sth = $this -> mdb2 -> prepare($query, $types);
		$result = $sth -> execute($params);

		if (PEAR::isError($result)) {
			return $result;
		}

		$result -> free();

		return $result;
	}

	/**
	 * Returns an object containing the meeting set described by the current request
	 * params. Object contains keys: meetings, filteredCount, totalCount.
	 *
	 * @param user if defined, return meetings owned by the user
	 * @return meeting result set
	 */
	public function getMeetingsAjax($user) {

		$meetings = $this -> doMeetingsAjaxQuery($user);
		$filteredTotal = $this -> getMeetingsAjaxFilteredTotal();
		$total = $this -> getTotalCount('meetings', 'id', $user);

		return array(
			'meetings' => $meetings,
			'filteredCount' => $filteredTotal,
			'totalCount' => $total
		);
	}

	/**
	 * Get the filtered count from the meetings ajax query. Must be called
	 * immediately after doMeetingsAjaxQuery().
	 *
	 * @return filtered result count
	 */
	private function getMeetingsAjaxFilteredTotal() {
		/* Data set length after filtering */
		$sQuery = "SELECT FOUND_ROWS()";
		$sth = $this -> mdb2 -> prepare($sQuery);
		$result = $sth -> execute();

		if (PEAR::isError($result)) {
			return $result;
		}

		$rows = $result -> fetchAll(MDB2_FETCHMODE_ASSOC);
		$result -> free();
		return $rows[0]['found_rows()'];
	}

	/**
	 * Returns an array of column names specifying which meeting table column values
	 * to return based on the user type.
	 *
	 * @param user user to base column list on
	 * @return array of meeting table column names
	 */
	private function getMeetingColumns($user) {
		if ($user instanceof Administrator) {
			return array(
				'date',
				'mentor',
				'meetings.mentee',
				'status',
				'type',
				'staff',
				'start_time',
				'length',
				'reason',
				'meetings.notes',
				'notes_admin',
				'active'
			);
		} else {
			return array(
				'date',
				'status',
				'type',
				'staff',
				'start_time',
				'length',
				'reason',
				'meetings.notes'
			);
		}
	}

	/**
	 * Performs a query for meetings based on an ajax request from a DataTable
	 *
	 * @param user if defined, return meetings owned by the user
	 * @return array of rows
	 */
	private function doMeetingsAjaxQuery($user) {

		// define table columns
		$aColumns = $this -> getMeetingColumns($user);
		$sIndexColumn = "id";

		// paging
		$sLimit = $this -> dbUtils -> dt_getLimit();

		// ordering
		$sOrder = $this -> dbUtils -> dt_getOrder($aColumns);

		// filtering across all table data
		$sWhere = $this -> dbUtils -> dt_getFiltering($aColumns);

		/* Individual column filtering */
		/* Adjust i to account for details column on client-side */
		for ($i = 0; $i < count($aColumns) + 1; $i++) {
			if ($_GET['bSearchable_' . $i] == "true" && $_GET['sSearch_' . $i] != '') {
				if ($sWhere == "") {
					$sWhere = "WHERE ";
				} else {
					$sWhere .= " AND ";
				}

				/*
				 * Some columns have display values that are different from the db values. Get
				 * the appropriate value to query with.
				 */
				$filterValue = $this -> getFilterValue($aColumns[$i - 1], $i, $_GET['sSearch_' . $i]);

				// mysql_real_escape_string($_GET['sSearch_' . $i])

				$sWhere .= $aColumns[$i - 1] . " LIKE '%" . $filterValue . "%' ";
			}
		}

		/* Filtering for administrator vs. mentor meeting queries */

		if ($user instanceof Mentor) {
			if ($sWhere == "") {
				$sWhere = "WHERE ";
			} else {
				$sWhere .= " AND ";
			}

			$sWhere .= "meetings.mentor = " . $user -> getId() . " ";
		}

		/*
		 * SQL queries
		 * Get data to display
		 */
		$sTable = 'meetings LEFT JOIN users ON meetings.mentor = users.id';
		$sQuery = "
		SELECT SQL_CALC_FOUND_ROWS " . str_replace(" , ", " ", implode(", ", $aColumns)) . "
		FROM $sTable $sWhere $sOrder $sLimit";

		$sth = $this -> mdb2 -> prepare($sQuery);
		$result = $sth -> execute();

		if (PEAR::isError($result)) {
			return $result;
		}

		$rows = $result -> fetchAll(MDB2_FETCHMODE_ASSOC);
		$result -> free();

		return $rows;
	}

	/**
	 * Some columns have a different display value than db value. This function
	 * returns the appropriate value to use for database queries to filter the
	 * column.
	 *
	 * @param colName column name in database
	 * @param i column index. Unadjusted column index.
	 * @param filterValue filter value from client
	 */
	private function getFilterValue($colName, $i, $filterValue) {

		// Meeting Status
		if ($colName === 'status') {
			if ($filterValue == 'Yes') {
				return 1;
			} else if ($filterValue == 'No') {
				return 0;
			}
		}

		return mysql_real_escape_string($_GET['sSearch_' . $i]);
	}

	/**
	 * Returns the total rows in the given table
	 *
	 * @param table database table to return row count for
	 * @param column id of the column to use for counting
	 * @param user user to get meetings for. if admin, get all.
	 *
	 * @return total row count
	 */
	private function getTotalCount($table, $column, $user) {
		$sQuery = "SELECT COUNT(" . $column . ") FROM $table";

		// if mentor, limit to meetings owned by the user
		if ($user instanceof Mentor) {
			$sQuery .= " WHERE mentor = " . $user -> getId();
		}

		$sth = $this -> mdb2 -> prepare($sQuery);
		$result = $sth -> execute();

		if (PEAR::isError($result)) {
			return $result;
		}

		$total = $result -> fetchAll(MDB2_FETCHMODE_ASSOC);
		$result -> free();

		$total = $total[0]['count(id)'];

		return $total;
	}

	/**
	 * Return all meetings owned by the given user, or all meetings if no user is
	 * specified.
	 *
	 * @param integer/string $userId id of the user whose meetings should be returned
	 */
	public function getMeetings($userId = NULL) {
		if (isset($userId)) {
			$query = "SELECT * FROM meetings WHERE meetings.mentor = :id AND meetings.deleted = false";
			$types = array('integer');
			$params = array('id' => $userId);
		} else {
			// query for retrieving active status of mentor user
			$query = "SELECT meetings.*, users.active FROM meetings LEFT JOIN users ON meetings.mentor = users.id WHERE meetings.deleted = false";
			$types = array();
			$params = array();
		}

		// limit to value date_limit only
		$query .= " AND meetings.date > :date";
		array_push($types, 'string');
		$params['date'] = $this -> date_limit;

		$sth = $this -> mdb2 -> prepare($query, $types);
		$result = $sth -> execute($params);

		if (PEAR::isError($result)) {
			return $result;
		}

		$rows = $result -> fetchAll(MDB2_FETCHMODE_ASSOC);
		$result -> free();

		return $rows;
	}

	/**
	 * Updates a meeting's information
	 *
	 * @param meetingId id of the meeting to update
	 * @param meetingDate new meeting date
	 * @param meetingStatus new meeting status
	 * @param meetingReason new meeting status reason
	 */
	public function updateMeeting($meetingId, $values, $types) {

		$params = array();

		// build the query string
		$query = '';
		foreach ($values as $key => $val) {
			if ($query == '') {
				$query .= "meetings.$key=:$key";
			} else {
				$query .= ",meetings.$key=:$key";
			}

			$params[$key] = $val;
		}

		// add meeting id
		$params['meetingId'] = $meetingId;
		array_push($types, 'integer');

		// build and execute query
		$query = "UPDATE meetings SET $query WHERE meetings.id=:meetingId";
		$s = $this -> mdb2 -> prepare($query, $types, MDB2_PREPARE_MANIP);
		$result = $s -> execute($params);

		return $result;
	}

}
?>