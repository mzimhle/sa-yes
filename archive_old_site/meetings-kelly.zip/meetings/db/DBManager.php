<?php
include ('debug.php');
require_once ('MDB2.php');

class DBManager {

	private static $instance;
	private $dsn = 'mysql://root@localhost/sayes_meetings';
	//private $dsn =
	// 'mysql://sayesmeetings:xLwUaweJy6wj4J@sayesmeetings.db.5503218.hostedresource.com/sayesmeetings';

	/** MDB2 instance for performing queries */
	private $mdb2;

	/** Helper class for user-related queries */
	private $userQueries;

	/** Helper class for meeting-related queries */
	private $meetingQueries;

	/** Helper class for report-related queries */
	private $reportQueries;

	/** Helper class for match-related queries */
	private $matchQueries;

	// limit things to only after this date
	private $date_limit = '2010-12-01';

	function __construct() {
		$this -> mdb2 = &MDB2::factory($this -> dsn);

		if (PEAR::isError($this -> mdb2)) {
			die($this -> mdb2 -> getMessage());
		}

		// initialize helper classes
		$this -> userQueries = new UserQueries($this, $this -> mdb2);
		$this -> meetingQueries = new MeetingQueries($this, $this -> mdb2);
		$this -> matchQueries = new MatchQueries($this, $this -> mdb2);
		$this -> reportQueries = new ReportQueries($this, $this -> mdb2);
	}

	/**
	 * Returns a singleton instance of the DBManager
	 */
	public static function getInstance() {

		if (!self::$instance) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Authenticate the given user credentials
	 *
	 * @param email email address of the user
	 * @param password password of the user
	 * @return the user object if authenticated, or null
	 */
	public function doLogin($email, $password) {

		// build and execute query
		$types = array(
			'text',
			'text'
		);
		$sth = $this -> mdb2 -> prepare("SELECT id FROM users WHERE users.email = :email AND users.password = PASSWORD(:password) AND users.active = TRUE", $types);
		$params = array(
			'email' => $email,
			'password' => $password
		);
		$result = $sth -> execute($params);

		if (PEAR::isError($result)) {
			return $result;
		}

		$row = $result -> fetchRow(MDB2_FETCHMODE_ASSOC);
		$result -> free();

		$userId = $row['id'];

		return $userId;
	}

	/**
	 * Return the id of the last inserted user row
	 *
	 * @return id of the last inserted row
	 */
	public function getLastUserId() {
		return $this -> userQueries -> getLastUserId();
	}

	/**
	 * Return the id of the last inserted match row
	 *
	 * @return id of the last inserted row
	 */
	public function getLastMatchId() {
		return $this -> matchQueries -> getLastMatchId();
	}

	/**
	 * Return the id of the last inserted meeting row
	 *
	 * @return id of the last inserted row
	 */
	public function getLastMeetingId() {
		return $this -> meetingQueries -> getLastMeetingId();
	}

	/**
	 * Returns the id of the owner of the meeting with the given id.
	 *
	 * @param id id of the meeting
	 */
	public function getMeetingOwner($id) {
		return $this -> meetingQueries -> getMeetingOwner($id);
	}

	/**
	 * Returns a User object for the user with the given id
	 *
	 * @param $id id of the user
	 * @return a populated User object
	 */
	public function getUser($id) {
		return $this -> userQueries -> getUser($id);
	}

	/**
	 * Returns a User object for the user with the given email
	 *
	 * @param $email email of the user
	 * @return a populated User object
	 */
	public function getUserByEmail($email) {
		return $this -> userQueries -> getUserByEmail($email);
	}

	/**
	 * Inserts a new mentor/mentee match into the database
	 *
	 * @param String $mentorId id of the mentor
	 * @param String $menteeId id of the mentee
	 * @param String $matchDate date of the match
	 */
	public function newMatch($mentorId, $menteeId, $matchDate, $notes) {
		return $this -> matchQueries -> newMatch($mentorId, $menteeId, $matchDate, $notes);
	}

	/**
	 * Inserts a new meeting into the database
	 *
	 * @param String $values
	 * @param String $types
	 * @param String $owner
	 * @return number of affected rows or error
	 */
	public function newMeeting($params, $types, $owner) {
		return $this -> meetingQueries -> newMeeting($params, $types, $owner);
	}

	/**
	 * Returns the id of the current mentee for the given mentor
	 *
	 * @param mentorId id of the mentor whose mentee is returned
	 * @return id of the mentee
	 */
	public function getCurrentMentee($mentorId) {
		return $this -> userQueries -> getCurrentMentee($mentorId);
	}

	/**
	 * Deletes a user from the database
	 *
	 * @param String $userId id of the user to delete
	 */
	public function deleteUser($userId) {
		return $this -> userQueries -> deleteUser($userId);
	}

	/**
	 * Deletes a meeting from the database
	 *
	 * @param String $meetingId id of the meeting to delete
	 */
	public function deleteMeeting($meetingId) {
		return $this -> meetingQueries -> deleteMeeting($meetingId);
	}

	/**
	 * Deletes a mentor/mentee match from the database
	 *
	 * @param String $matchId id of the match to delete
	 */
	public function deleteMatch($matchId) {
		return $this -> matchQueries -> deleteMatch($matchId);
	}

	/**
	 * Returns the date of the match between the mentor and mentee
	 *
	 * @param $mentorId id of the mentor
	 * @param $menteeId id of the mentee
	 * @return date of the match
	 */
	public function getMatchDate($mentorId, $menteeId) {
		return $this -> matchQueries -> getMatchDate($mentorId, $menteeId);
	}

	/**
	 * Inserts the given user into the database
	 *
	 * @param user user to save
	 * @return number of rows affected, or error
	 */
	public function newUser($user) {
		return $this -> userQueries -> newUser($user);
	}

	/**
	 * Activates or deactivates the user with the given id based on the given active
	 * state
	 *
	 * @param userId id of the user to activate/deactive
	 * @param active whether the user should be set to active or deactive
	 * @return number of affected rows, or error
	 */
	public function activateUser($userId, $active) {
		return $this -> userQueries -> activateUser($userId, $active);
	}

	/**
	 * Returns all users of the selected type. If no type is specified, returns all
	 * users.
	 *
	 * @param type type of users to return
	 * @return all users of the specified type as rows
	 */
	public function getUsers($type = NULL) {
		return $this -> userQueries -> getUsers($type);
	}

	/**
	 * Returns an object containing the user set described by the current request
	 * params. Object contains keys: users, filteredCount, totalCount.
	 *
	 * @param type type of users to return
	 * @return meeting result set
	 */
	public function getUsersAjax($type = NULL) {
		return $this -> userQueries -> getUsersAjax($type);
	}

	/**
	 * Returns all mentor/mentee matches
	 *
	 * @return all matches as rows
	 */
	public function getMatches() {
		return $this -> matchQueries -> getMatches();
	}

	/**
	 * Returns whether or not the given user has administrator privileges
	 *
	 * @param userId id of the user to check
	 * @return whether or not the user has administrator privileges
	 */
	function isAdmin($userId) {
		return $this -> userQueries -> isAdmin($userId);
	}

	/**
	 * Returns whether or not the given user is a mentor
	 *
	 * @param userId id of the user to check
	 * @return whether or not the user is a mentor
	 */
	function isMentor($userId) {
		return $this -> userQueries -> isMentor($userId);
	}

	/**
	 * Returns the id of the group with the given name.
	 *
	 * @param groupAlias alias of the group
	 * @return the id of the group
	 */
	function getGroupId($groupAlias) {
		return $this -> userQueries -> getGroupId($groupAlias);
	}

	/**
	 * Returns the alias of the group with the given id.
	 *
	 * @param groupId id of the group
	 * @return the alias of the group
	 */
	function getGroupAlias($groupId) {
		return $this -> userQueries -> getGroupAlias($groupId);
	}

	/**
	 * Returns the type of the user (Mentor, Mentee, Admin) specified by the
	 * given user id
	 *
	 * @param userId id of the user
	 * @return the user type
	 */
	function getUserType($userId) {
		return $this -> userQueries -> getUserType($userId);
	}

	/**
	 * Returns a list of valid user types
	 *
	 * @return list of user types
	 */
	function getUserTypes() {
		return $this -> userQueries -> getUserTypes();
	}

	/**
	 * Returns an object containing the meeting set described by the current request
	 * params. Object contains keys: meetings, filteredCount, totalCount.
	 *
	 * @param user if defined, return meetings owned by the user
	 * @return meeting result set
	 */
	public function getMeetingsAjax($user) {
		return $this -> meetingQueries -> getMeetingsAjax($user);
	}

	/**
	 * Return all meetings owned by the given user, or all meetings if no user is
	 * specified.
	 *
	 * @param integer/string $userId id of the user whose meetings should be returned
	 */
	public function getMeetings($userId = NULL) {
		return $this -> meetingQueries -> getMeetings($userId);
	}

	/**
	 * Updates a user's information. Given user object contains the user id and all
	 * values that should be set in the database.
	 *
	 * @param updatedUser user object containing updated information
	 */
	public function updateUser($updatedUser) {
		return $this -> userQueries -> updateUser($updatedUser);
	}

	/**
	 * Updates a match's information
	 *
	 * @param matchId id of the match to update
	 * @param matchDate new match date
	 */
	public function updateMatch($matchId, $matchDate, $notes) {
		return $this -> matchQueries -> updateMatch($matchId, $matchDate, $notes);
	}

	/**
	 * Updates a meeting's information
	 *
	 * @param meetingId id of the meeting to update
	 * @param meetingDate new meeting date
	 * @param meetingStatus new meeting status
	 * @param meetingReason new meeting status reason
	 */
	public function updateMeeting($meetingId, $values, $types) {
		return $this -> meetingQueries -> updateMeeting($meetingId, $values, $types);
	}

	/**
	 * Returns the display name for the user
	 *
	 * @param userId the id of the user whose name should be returned
	 * @return the display name of the user
	 */
	function getDisplayName($userId) {
		return $this -> userQueries -> getDisplayName($userId);
	}

	/**
	 * Performs the given query and returns the first resulting row
	 *
	 * @param query query string
	 * @return the first result row
	 */
	public function doSingleSelect($query) {
		$result = $this -> mdb2 -> query($query);

		if (PEAR::isError($result)) {
			return $result;
		}

		$row = $result -> fetchRow(MDB2_FETCHMODE_ASSOC);
		$result -> free();

		return $row;
	}

	/**
	 * Performs the given query and returns all resulting rows
	 *
	 * @param query query string
	 * @return all resulting rows
	 */
	public function doMultiSelect($query) {
		$result = $this -> mdb2 -> query($query);

		if (PEAR::isError($result)) {
			return $rows;
		}

		$rows = $result -> fetchAll(MDB2_FETCHMODE_ASSOC);
		$result -> free();

		return $rows;
	}

	/**
	 * Runs a report for all meetings within a specified date range with a specified
	 * meeting status
	 *
	 * @param startDate beginning of the date range
	 * @param endDate end of date range
	 * @param allDates whether to run report for all dates
	 * @param status meeting status to run report for
	 * @return meeting results
	 */
	public function doMeetingReport($startDate, $endDate, $allDates, $status) {
		return $this -> reportQueries -> doMeetingReport($startDate, $endDate, $allDates, $status);
	}

	/**
	 *
	 */
	public function doMeetingStatusReport($startDate, $endDate) {
		return $this -> reportQueries -> doMeetingStatusReport($startDate, $endDate);
	}

	/**
	 * Returns a limit clause for a DataTables AJAX query. Limit clause is for paging
	 * of results.
	 *
	 * @return limit clause determined by request parameters
	 */
	public function dt_getLimit() {
		$sLimit = '';
		if (isset($_GET['iDisplayStart']) && $_GET['iDisplayLength'] != '-1') {
			$sLimit = "LIMIT " . mysql_real_escape_string($_GET['iDisplayStart']) . ", " . mysql_real_escape_string($_GET['iDisplayLength']);
		}
		return $sLimit;
	}

	/**
	 * Returns an orderby clause for a DataTables AJAX query. Orderby clause is for
	 * sort order of results.
	 *
	 * @param aColumns array of column names
	 * @return orderby clause determined by request parameters
	 */
	public function dt_getOrder($aColumns) {
		$sOrder = '';
		if (isset($_GET['iSortCol_0'])) {
			$sOrder = "ORDER BY  ";
			for ($i = 0; $i < intval($_GET['iSortingCols']); $i++) {
				if ($_GET['bSortable_' . intval($_GET['iSortCol_' . $i])] == "true") {

					// adjust column index to account for details column on client-side
					$sOrder .= $aColumns[intval($_GET['iSortCol_' . $i])] . "
				 	" . mysql_real_escape_string($_GET['sSortDir_' . $i]) . ", ";
				}
			}

			$sOrder = substr_replace($sOrder, "", -2);
			if ($sOrder == "ORDER BY") {
				$sOrder = "";
			}
		}
		return $sOrder;
	}

	/**
	 * Returns a WHERE clause for DataTables AJAX query. Where clause is for
	 * filtering across all table data.
	 *
	 * @param aColumns array of column names
	 * @return where clause determined by request parameters
	 */
	public function dt_getFiltering($aColumns) {
		/*
		 * Filtering
		 * NOTE this does not match the built-in DataTables filtering which does it
		 * word by word on any field. It's possible to do here, but concerned about
		 * efficiency
		 * on very large tables, and MySQL's regex functionality is very limited
		 */
		$sWhere = "";
		if ($_GET['sSearch'] != "") {
			$sWhere = "WHERE (";
			for ($i = 0; $i < count($aColumns); $i++) {
				$sWhere .= $aColumns[$i] . " LIKE '%" . mysql_real_escape_string($_GET['sSearch']) . "%' OR ";
			}
			$sWhere = substr_replace($sWhere, "", -3);
			$sWhere .= ')';
		}

		return $sWhere;
	}

}
?>