<?php
class MatchQueries {

	/** DBManager instance for utility functions */
	private $dbUtils;
	
	/** MDB2 instance for performing queries */
	private $mdb2;

	// limit things to only after this date
	private $date_limit = '2010-12-01';

	function __construct($dbm, $mdb2) {
		$this -> dbUtils = $dbm;
		$this -> mdb2 = $mdb2;
	}

	/**
	 * Return the id of the last inserted match row
	 *
	 * @return id of the last inserted row
	 */
	public function getLastMatchId() {
		$sth = $this -> mdb2 -> prepare("SELECT matches.id FROM matches WHERE matches.id = LAST_INSERT_ID()");
		$result = $sth -> execute();
		$row = $result -> fetchRow(MDB2_FETCHMODE_ASSOC);
		return $row['id'];
	}
	
	/**
	 * Inserts a new mentor/mentee match into the database
	 *
	 * @param String $mentorId id of the mentor
	 * @param String $menteeId id of the mentee
	 * @param String $matchDate date of the match
	 */
	public function newMatch($mentorId, $menteeId, $matchDate, $notes) {

		$types = array(
			'integer',
			'integer',
			'text',
			'text'
		);
		$sth = $this -> mdb2 -> prepare("INSERT INTO matches (mentor,mentee,match_date,notes) VALUES (:mentor, :mentee,:matchDate,:notes)", $types);
		$params = array(
			'mentor' => $mentorId,
			'mentee' => $menteeId,
			'matchDate' => $matchDate,
			'notes' => $notes
		);
		$result = $sth -> execute($params);

		if (PEAR::isError($result)) {
			return $result;
		}

		$row = $result -> fetchRow(MDB2_FETCHMODE_ASSOC);
		$result -> free();

		return $row;
	}
	
		/**
	 * Deletes a mentor/mentee match from the database
	 *
	 * @param String $matchId id of the match to delete
	 */
	public function deleteMatch($matchId) {

		$query = "UPDATE matches SET matches.deleted = true WHERE matches.id = :id";
		$types = array('integer');
		$params = array('id' => $matchId);
		$sth = $this -> mdb2 -> prepare($query, $types);
		$result = $sth -> execute($params);

		if (PEAR::isError($result)) {
			return $result;
		}

		$result -> free();

		return $result;
	}
	
	/**
	 * Returns the date of the match between the mentor and mentee
	 *
	 * @param $mentorId id of the mentor
	 * @param $menteeId id of the mentee
	 * @return date of the match
	 */
	public function getMatchDate($mentorId, $menteeId) {

		$query = "SELECT matches.match_date FROM matches WHERE mentor = ? AND mentee = ?";
		$types = array(
			'integer',
			'integer'
		);
		$params = array(
			$mentorId,
			$menteeId
		);
		$sth = $this -> mdb2 -> prepare($query, $types);
		$result = $sth -> execute($params);

		if (PEAR::isError($result)) {
			return $result;
		}

		$row = $result -> fetchRow(MDB2_FETCHMODE_ASSOC);

		$result -> free();

		return $row['match_date'];
	}
	
	/**
	 * Returns all mentor/mentee matches
	 *
	 * @return all matches as rows
	 */
	public function getMatches() {
		$query = "SELECT * FROM matches WHERE matches.deleted != true";
		$rows = $this -> dbUtils -> doMultiSelect($query);
		return $rows;
	}
	
	/**
	 * Updates a match's information
	 *
	 * @param matchId id of the match to update
	 * @param matchDate new match date
	 */
	public function updateMatch($matchId, $matchDate, $notes) {

		$types = array(
			'text',
			'text',
			'integer'
		);
		$params = array(
			$matchDate,
			$notes,
			$matchId
		);

		// build and execute query
		$query = "UPDATE matches SET matches.match_date = ?, matches.notes = ? WHERE matches.id=?";
		$s = $this -> mdb2 -> prepare($query, $types, MDB2_PREPARE_MANIP);
		$result = $s -> execute($params);

		return $result;
	}
}
?>