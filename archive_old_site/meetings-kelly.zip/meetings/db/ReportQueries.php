<?php
class ReportQueries {

	/** DBManager instance for utility functions */
	private $dbUtils;

	/** MDB2 instance for performing queries */
	private $mdb2;

	// limit things to only after this date
	private $date_limit = '2010-12-01';

	function __construct($dbm, $mdb2) {
		$this -> dbUtils = $dbm;
		$this -> mdb2 = $mdb2;
	}

	/**
	 * Runs a report for all meetings within a specified date range with a specified
	 * meeting status
	 *
	 * @param startDate beginning of the date range
	 * @param endDate end of date range
	 * @param allDates whether to run report for all dates
	 * @param status meeting status to run report for
	 * @return meeting results
	 */
	public function doMeetingReport($startDate, $endDate, $allDates, $status) {

		$query = "SELECT date,mentor,mentee,status,type,staff,start_time,length,reason,notes,notes_admin FROM meetings WHERE meetings.status = :status";
		$types = array('integer');
		$params = array('status' => $status);

		if (!isset($allDates)) {
			$query .= " AND meetings.date BETWEEN :start AND :end";
			array_push($types, 'text');
			array_push($types, 'text');
			$params['start'] = $startDate;
			$params['end'] = $endDate;
		}

		$sth = $this -> mdb2 -> prepare($query, $types);
		$result = $sth -> execute($params);

		if (PEAR::isError($result)) {
			return $result;
		}

		$rows = $result -> fetchAll(MDB2_FETCHMODE_ASSOC);
		$result -> free();

		return $rows;

	}

	/**
	 *
	 */
	public function doMeetingStatusReport($startDate, $endDate) {

		// data to return
		$data = array();

		// get all users
		$query = "SELECT ID FROM users";
		$query .= " WHERE deleted = 0 AND active = 1";
		$query .= " AND user_group = 2";
		$sth = $this -> mdb2 -> prepare($query);
		$result = $sth -> execute($params);

		if (PEAR::isError($result)) {
			return $result;
		}

		$userIds = $result -> fetchCol(0);
		$result -> free();

		foreach ($userIds as $key => $userId) {

			// get meetings in the date range for the user
			$query = "SELECT status FROM meetings";
			$query .= " WHERE date BETWEEN :start AND :end";
			$query .= " AND mentor = :userId";
			$types = array(
				'text',
				'text',
				'int'
			);
			$params = array(
				'start' => $startDate,
				'end' => $endDate,
				'userId' => $userId
			);

			$sth = $this -> mdb2 -> prepare($query, $types);
			$result = $sth -> execute($params);

			if (PEAR::isError($result)) {
				return $result;
			}

			$meetings = $result -> fetchAll(MDB2_FETCHMODE_ASSOC);
			$result -> free();

			// see if there was a meeting and save the status if there was
			$meetingStatus = null;
			if (count($meetings) > 0) {
				$meetingStatus = $meetings[0]['status'];
			}

			// add user/meeting to the result set
			array_push($data, array(
				"id" => $userId,
				"status" => $meetingStatus
			));
		}

		return $data;

	}

}
?>