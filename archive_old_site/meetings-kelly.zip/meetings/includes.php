<!-- <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.6.4/jquery.min.js"></script>
<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.8.16/jquery-ui.min.js"></script>
<script type="text/javascript" src="http://ajax.aspnetcdn.com/ajax/jquery.validate/1.9/jquery.validate.min.js"></script> -->

<script type="text/javascript" src="js/jquery-1.7.1.min.js"></script>
<script type="text/javascript" src="js/jquery-ui-1.8.16.custom.min.js"></script>
<script type="text/javascript" src="js/jquery.validate.min.js"></script>

<script type="text/javascript" src="js/jquery.timepicker.js"></script>
<script type="text/javascript" src="js/jquery.dataTables.js"></script>
<script type="text/javascript" src="js/extras/TableTools/media/js/TableTools.min.js"></script>
<script type="text/javascript" src="js/table-utils.js"></script>
<script type="text/javascript" src="js/main.js"></script>

<link rel="stylesheet" href="css/humanity/jquery-ui-1.8.16.custom.css" />
<link rel="stylesheet" href="css/TableTools.css" />
<link rel="stylesheet" href="css/datatables/demo_table.css" />
<link rel="stylesheet" href="css/styles.css" />

<!--[if IE 7]>
	<style>
		pre { white-space: normal; }
	</style>
<![endif]-->

<title>SA-YES Meeting Tracker</title>